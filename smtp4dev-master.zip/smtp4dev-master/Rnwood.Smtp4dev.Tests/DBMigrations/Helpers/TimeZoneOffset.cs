﻿namespace Rnwood.Smtp4dev.Tests.DBMigrations.Helpers
{
    public class TimeZoneOffset
    {
        public string Id { get; set; }
        public string SerializedTimeZone { get; set; }
        public int Offset { get; set; }
    }
}