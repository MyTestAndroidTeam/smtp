﻿export default class FileStreamResult extends Array<number>
{
}