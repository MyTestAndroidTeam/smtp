﻿namespace Rnwood.Smtp4dev.Server
{
    public class ClientOptions
    {
        /// <summary>
        /// Page size for message pagination
        /// </summary>
        public int PageSize { get; set; } = 25;
    }
}